<?php
session_start();
if(isset($_SESSION["session_username"])){
header("location:intropage.php");
}

?>

<?php
require_once("includes/connection.php");
?>
<?php
if(isset($_POST["login"])){
if(empty($_POST['name']) or empty($_POST['password'])) {
echo "All fields are required!";
}
else {
$name=htmlspecialchars($_POST['name']);
$password=htmlspecialchars($_POST['password']);
$query =mysqli_query("SELECT * FROM users WHERE name='".$name."' AND password='".$password."'");
$numrows=mysql_num_rows($query);
if($numrows!=0)
{
$_SESSION['session_username']=$username;
/* Перенаправление браузера */
if(isset($_SESSION["session_username"])){
echo '<meta http-equiv="refresh" content="0;URL=/index.php">';

}
else {
echo "Invalid username or password!";
}
}
}
}
?>