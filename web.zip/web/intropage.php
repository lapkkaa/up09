
	
  <!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NDS</title>
    <link rel="stylesheet" href="./css/reset.css">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<link rel="stylesheet" href="./css/reset.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="./css/style.css">
<link rel=”icon” href="./img/favicon.ico" type=”image/x-icon”>.
<?php require_once("includes/connection.php"); ?>
</head>
<body>
    <header class="header">
        <div class="wrapper">
           <div class="header__wrapper">
            <div class="header_logo">
                <a href="MAIN.php" class="header__link">
                <img src="./img/logo.png" alt="NDS" width=200 height=50 class="header__logo-pic">
                </a>
            </div>

            <nav class="header__nav">
                <ul class="header__list">
                    <li class="header__item">
                        <a href="./catalogue.php" class="header__link">Каталог</a>
                    </li>
                    <li class="header__item">
                        <a href="./bin.php" class="header__link">Корзина</a>
                    </li>
                    <li class="header__item">
                    <?php
                if (!$_COOKIE['user'] == '') {
                    echo '<a href="logout.php" class="header__link">Выход</a>';
                }
                if ($_COOKIE['user'] == '') {
                    echo '<a href="login.php" class="header__link">Вход</a>';
                }
            ?>
                    </li>
                </ul>
            </nav>
           </div>

        </div>
    </header>

    <main class="main">
        <section class="intro">
            <div class="wrapper">
<div id="welcome">
<h2>Добро пожаловать, <span><?php echo $_COOKIE['user'];?>! </span></h2>
  <p><a href="logout.php">Выйти</a> из системы</p>
</div>
	
<?php include("includes/footer.php"); ?>
	
