<?php
session_start();
include 'includes/connection.php';

?>




<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NDS</title>
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<link rel="stylesheet" href="./css/reset.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel=”icon” href="./img/favicon.ico" type=”image/x-icon”>.
<?php require_once("includes/connection.php"); ?>
</head>
<body>
    <header class="header">
        <div class="wrapper">
           <div class="header__wrapper">
            <div class="header_logo">
            <a href="MAIN.php" class="header__link">
                <img src="./img/logo.png" alt="NDS" width=200 height=50 class="header__logo-pic">
                </a>
            </div>

            <nav class="header__nav">
                <ul class="header__list">
                    <li class="header__item">
                        <a href="./catalogue.php" class="header__link">Каталог</a>
                    </li>
                    <li class="header__item">
                        <a href="./bin.php" class="header__link">Корзина</a>
                    </li>
                    <li class="header__item">
                    <?php
                if (!$_COOKIE['user'] == '') {
                    echo '<a href="logout.php" class="header__link">Выход</a>';
                }
                if ($_COOKIE['user'] == '') {
                    echo '<a href="login.php" class="header__link">Вход</a>';
                }
            ?>
                    </li>
                </ul>
            </nav>
           </div>

        </div>
    </header>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'add':
            $id = isset($_GET['model']);
            $query = "SELECT * FROM `catalog` WHERE model = '$id' ";
            $resultt = $link->query($query);
            $product = $resultt->fetch_assoc();

            if (!isset($_SESSION['bin'])) {
                $_SESSION['bin'] = [];
            }

            if (isset($_SESSION['bin'][$id])) {
                $_SESSION['bin'][$id]['quantity']++;
            } else {
                $_SESSION['bin'][$id] = [
                    'model' => $product['model'],
                    'price' => $product['price'],
                    'quantity' => 1
                ];
            }

            header('Location: bin.php');
            break;

        case 'remove':
            $id = $_GET['model'];
            if (isset($_SESSION['bin'][$id])) {
                unset($_SESSION['bin'][$id]);
            }

            header('Location: bin.php');
            break;
    }
}

$total_price = 0;
if (isset($_SESSION['bin'])) {
    foreach ($_SESSION['bin'] as $item) {
        $total_price += $item['price'] * $item['quantity'];
    }
}
?>
    <main class="main">
        <section class="intro">
            <div class="wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Итого</th>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (isset($_SESSION['bin']) as $id => $item): ?>
                        <tr>
                            <td><?php echo $item['model']; ?></td>
                            <td><?php echo $item['price']; ?> руб.</td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><?php echo $item['price'] * $item['quantity']; ?> руб.</td>
                            <td><a href="bin.php?action=remove&id=<?php echo $id; ?>">Удалить</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p>Общая стоимость: <?php echo $total_price; ?> руб.</p>
            <a href="checkout.php">Оформить заказ</a> 
           
            </div>
        </section>
    </main>
    <?php include("includes/footer.php"); ?>